"""Envoie uniquement les deux documents du rapport, via un rclone déjà autorisé.

Aucun code du lot COUTS_L1_V01 n'est importé ou exécuté.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remote', default='gdrive', help='Nom du remote rclone Google Drive')
    parser.add_argument('--folder-id', required=True, help='ID du dossier POUR CLAUDE dans son URL Drive')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+', args.remote):
        parser.error('Nom de remote invalide.')
    if not re.fullmatch(r'[A-Za-z0-9_-]{10,}', args.folder_id):
        parser.error('ID de dossier invalide : fournir uniquement la partie après /folders/.')
    binary = shutil.which('rclone')
    if not binary:
        parser.error('rclone est absent. Voir MODE_EMPLOI.md.')
    root = Path(__file__).resolve().parent
    expected = json.loads((root / 'FICHIERS_A_ENVOYER.json').read_text(encoding='utf-8'))
    allowed = {'RETOUR_COUTS_L1_V01_2026-11-07.md', 'COUTS_L1_V01_INTEGRITE.json'}
    if set(expected) != allowed:
        raise ValueError('La liste des documents à transférer ne correspond pas au rapport prévu.')
    # Vérifier tous les documents avant le premier envoi.
    for name, digest in expected.items():
        actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError('Document absent ou empreinte différente : ' + name)
    remotes = subprocess.run([binary, 'listremotes'], check=True, capture_output=True, text=True)
    if args.remote + ':' not in remotes.stdout.splitlines():
        raise ValueError('Remote non configuré : ' + args.remote + '. Voir MODE_EMPLOI.md.')
    flags = ['--drive-root-folder-id', args.folder_id]
    print('Destination : https://drive.google.com/drive/folders/' + args.folder_id, flush=True)
    for name, digest in expected.items():
        destination = args.remote + ':' + name
        # copyto n'efface pas le dossier. immutable refuse un fichier différent déjà présent.
        subprocess.run([binary, 'copyto', str(root / name), destination, '--immutable', *flags], check=True)
        downloaded = subprocess.run([binary, 'cat', destination, *flags], check=True, capture_output=True)
        if hashlib.sha256(downloaded.stdout).hexdigest() != digest:
            raise ValueError('Échec de vérification du document distant : ' + name)
        print('ENVOYÉ ET VÉRIFIÉ : ' + name, flush=True)
    print('Terminé : les deux documents distants correspondent aux SHA256 locaux.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        print('TRANSFERT NON TERMINÉ : ' + str(exc), file=sys.stderr)
        print('Un document déjà envoyé peut être présent ; aucun succès global n’est confirmé.', file=sys.stderr)
        sys.exit(1)
