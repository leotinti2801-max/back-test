# Retour à Claude — COUTS_L1_V01

Date : 7 novembre 2026 (Europe/Paris).

Revue statique demandée par Léo. Aucun script du lot, test, backtest, collecteur ou accès MT5 n'a été exécuté. Les seuls traitements locaux ont concerné la lecture de l'archive, les SHA256, l'extraction de consultation et la rédaction de ce rapport. Le journal de 19 tests fourni dans le lot a été lu ; ses résultats n'ont pas été reproduits ni certifiés ici. Les commandes des README et fichiers BAT n'ont pas été suivies.

## Conclusion

**Intégrité confirmée ; absence d'appels d'ordre constatée dans les sources ; garanties de décalage fiable, de reprise sans doublon et de collecte complète non validées en l'état.**

Les corrections prioritaires concernent l'estimation du décalage à partir d'un tick ancien, l'écriture non transactionnelle d'une heure, la distinction entre durée de maintien d'une cotation et complétude de l'historique, les critères de complétude par fenêtre et l'acceptation des valeurs non finies. La statistique visée par le seuil doit aussi être définie sans ambiguïté.

Le comparateur strict au seuil de 1,75 pip est bien présent. Cela ne suffit pas à valider un verdict calculé sur des données insuffisantes ou invalides.

## 1. Intégrité de la livraison

| Contrôle | Résultat |
| --- | --- |
| SHA256 du ZIP | 2a05d741bb5ca5e124ad56a53294a3370bd38f0325ea1972deaf17e25a505870 — conforme à la valeur transmise par Léo |
| SHA256 de MANIFEST_SHA256.json | abbf5af5db636d1ad6896e23bc24c714147c5461def7e3d0a331d84cf4b7b0d2 — conforme à la valeur transmise par Léo |
| Entrées ZIP | 14 : 12 fichiers, dont le manifeste, et 2 dossiers |
| Fichiers annoncés par le manifeste | 11 |
| Empreintes individuelles | **11 sur 11 conformes** |
| Fichiers supplémentaires hors manifeste | Le manifeste lui-même uniquement |
| Doublons de noms / chemins sortant du dossier / liens symboliques | Aucun détecté dans le ZIP |

La liste complète des empreintes attendues et calculées est fournie dans **COUTS_L1_V01_INTEGRITE.json**, avec le résultat individuel de chaque comparaison. Les fichiers sources ont été extraits pour lecture dans /workspace/reviews/COUTS_L1_V01 ; ils n'ont pas été modifiés.

Une empreinte conforme confirme l'identité des fichiers livrés, pas leur correction fonctionnelle.

## 2. Résultat des cinq points demandés

| Point | Résultat de la lecture |
| --- | --- |
| Lecture seule / aucun ordre | Confirmé dans le code livré : aucune voie d'envoi, de modification ou de fermeture d'ordre appelée. symbol_select modifie seulement le Market Watch. |
| Spread pondéré par le temps | Formule de moyenne pondérée cohérente sur un historique complet et correctement ordonné ; limites de couverture, valeurs non finies et égalités de timestamp à corriger. |
| Décalage serveur–UTC | Non fiable : l'arrondi confond âge du tick et décalage. Le contrat réel des timestamps API n'est pas établi par les tests synthétiques. |
| Reprise sans doublon | Vraie après un passage entièrement terminé ; non garantie après une interruption entre les écritures CSV, gzip et état. |
| Verdict au seuil de 1,75 pip | Comparaison stricte correcte ; complétude, validation numérique et définition de la statistique ne permettent pas un verdict final fiable en l'état. |

## 3. Défauts prioritaires

Les exemples ci-dessous sont des déductions de lecture, **pas des scénarios exécutés**. P1 désigne un défaut qui compromet une garantie essentielle du lot ; P2 un point de méthode ou de robustesse à traiter explicitement.

### C01 — P1 — Un tick périmé peut devenir un faux décalage horaire

Références : **collecte_couts.py:90–99**, **245–258**, **271–278** ; tests/test_couts.py:113–119 et 200–215.

mesurer_decalage arrondit la différence entre timestamp du tick et horloge PC au multiple de 1 800 secondes le plus proche, puis contrôle seulement le résidu de cet arrondi. Un âge proche d'un multiple de 30 minutes disparaît donc dans le décalage estimé.

Exemple : avec un décalage réel supposé de +7 200 s et un dernier tick âgé de 3 600 s, brut vaut 3 600, arrondi vaut 3 600 et résidu vaut zéro. La fonction accepte **+3 600 s au lieu de refuser le tick vieux d'une heure**. Avec un timestamp API déjà UTC, le même raisonnement accepte −3 600 s.

Le décalage ainsi enregistré est ensuite appliqué aux bornes de copy_ticks_range et aux timestamps archivés. Une heure de marché peut être récupérée sous l'étiquette d'une autre heure UTC, ce qui fausse précisément les fenêtres de coût étudiées. Les tests rejettent un tick vieux de cinq minutes ou de 36 heures, mais ne couvrent pas les âges de 30/60 minutes qui déclenchent l'alias.

Correction attendue : établir d'abord le contrat des timestamps retournés par l'API, distinct de l'heure affichée par le terminal ; vérifier la fraîcheur indépendamment d'un offset librement arrondi ; ne pas déduire un changement d'offset d'un seul tick possiblement figé. Conserver les timestamps originaux et la provenance des conversions.

Le faux MT5 des tests ajoute volontairement un offset aux timestamps et aux requêtes (tests/test_couts.py:54–66). Il vérifie la cohérence de cette hypothèse, pas sa validité sur FTMO/MT5. La sémantique réelle n'a pas été vérifiée sur un terminal dans cet audit. La consultation de la documentation publique MetaQuotes a échoué avec HTTP 403 ; aucune citation de cette page n'est présentée comme vérifiée ici.

Autre limite déjà reconnue au README:63 : un unique offset mesuré maintenant est réutilisé pour les 72 heures rattrapées. Si une conversion d'heure serveur est effectivement nécessaire, un rattrapage traversant un changement d'heure demande l'offset historique applicable, ou un refus explicite des heures ambiguës.

### C02 — P1 — La reprise après interruption n'est pas idempotente

Références : **collecte_couts.py:279–288**, **200–209** ; tests/test_couts.py:179–198 ; **analyse_couts.py:69–88**.

Une heure est écrite successivement dans le CSV, dans le gzip quotidien, puis dans etat.json. Seul le remplacement de l'état est atomique. Il n'existe ni transaction couvrant ces trois sorties ni contrôle d'unicité de la clé symbole/heure dans les fichiers produits.

Une interruption après l'ajout du CSV mais avant la validation de l'état entraîne un nouvel ajout de la même heure au redémarrage. Après l'écriture du gzip et avant l'état, les ticks de cette heure sont aussi ajoutés une seconde fois. Une interruption pendant un ajout gzip peut laisser un membre tronqué. Une double ouverture du collecteur n'est pas verrouillée non plus.

L'analyse ne détecte ni ne résout les doublons : elle les compte dans les effectifs horaires et dans les médianes. Le compteur global de dates distinctes reste, lui, dédupliqué ; il ne faut pas confondre ces deux compteurs.

Correction attendue : publication atomique de blocs horaires identifiés de façon unique, ou mécanisme transactionnel équivalent ; reconstruction/réconciliation des sorties à la reprise ; détection des incohérences ; verrou d'instance. Ne pas supprimer indistinctement les ticks partageant une milliseconde : plusieurs cotations distinctes peuvent avoir le même timestamp.

Le test existant vérifie deux appels après réussite complète du premier. Il ne vérifie pas une coupure entre les étapes d'écriture.

### C03 — P1 — La « couverture » ne prouve pas la complétude de l'historique

Références : **collecte_couts.py:145–162**, **274–288** ; **analyse_couts.py:36–45** ; config_couts.json:12.

Les poids vont du premier tick valide jusqu'à la fin de l'heure. Leur somme vaut donc **fin d'heure moins premier tick**, indépendamment des trous internes et de la date du dernier tick.

Une réponse partielle ne contenant qu'un tick au début de l'heure obtient couverture_s = 3 600 et trou_max_s = 3 600. Elle satisfait le filtre de 1 800 secondes et son unique spread est propagé sur toute l'heure. trou_max_s et n_invalides ne sont pas utilisés pour qualifier l'heure dans l'analyse.

Un intervalle sans nouveau tick n'est pas, à lui seul, une preuve de données manquantes : une cotation peut légitimement rester inchangée. Le défaut est de présenter cette durée de maintien comme une preuve de couverture sans distinguer ce cas d'une réponse historique incomplète.

De plus, seul le retour None déclenche une nouvelle tentative. Une liste vide est immédiatement enregistrée comme heure traitée, y compris pendant une heure ouvrée, sans distinguer fermeture de marché et historique temporairement indisponible. Elle ne sera plus demandée automatiquement.

Correction attendue : définir et tracer les critères de qualité du flux et d'exhaustivité des réponses ; distinguer fermeture attendue, absence d'historique, données invalides et cotation inchangée ; prévoir une réconciliation des heures vides ou suspectes. Une durée ou un nombre de ticks isolé ne suffit pas à attester tous ces critères.

### C04 — P1 — « Collecte complète » peut être vrai avec une fenêtre visée absente

Références : **analyse_couts.py:90–113**, **127–135**.

Les 20 jours sont comptés sur l'union de toutes les heures utilisables. La présence de NFP/CPI/FOMC est également évaluée globalement par appartenance à une heure. Il n'y a pas de minimum de jours distincts par symbole et par fenêtre visée.

Exemple logique : 20 dates comportant surtout 11 h, auxquelles s'ajoutent les heures des trois annonces, suffisent à rendre collecte_complete vrai. La fenêtre WMR peut pourtant ne contenir aucune observation et afficher PAS DE DONNÉES dans le même rapport. Une autre fenêtre peut recevoir un verdict sur une seule observation.

La couverture d'une annonce signifie seulement qu'une ligne horaire de cette heure a été retenue. Elle ne prouve pas la disponibilité des cotations au voisinage de l'annonce, notamment avec le problème C03.

Correction attendue : matrice de présence par date/symbole/fenêtre, minimum de jours distincts pour chaque verdict, contrôle des plages requises autour des événements et liste explicite des manques. Le statut final doit dépendre de ces contrôles ; conserver un statut DONNÉES INSUFFISANTES tant qu'ils échouent.

### C05 — P1 — NaN peut produire « SOUS LE SEUIL »

Références : **collecte_couts.py:135–162** ; **analyse_couts.py:36–45**, **74–108**.

Les prix sont refusés s'ils sont non positifs ou si ask < bid, mais il n'y a pas de contrôle de finitude. Les comparaisons avec NaN sont fausses : un prix NaN peut passer ces conditions et produire un spread_moyen_temps NaN. L'analyse accepte aussi le texte nan dans le CSV, ainsi qu'une couverture non finie.

Un coût NaN n'est pas supérieur à 1,75. Le branchement actuel choisit donc **SOUS LE SEUIL** au lieu de signaler une donnée invalide. Ce n'est pas une mesure de coût acceptable.

Correction attendue : contrôler explicitement la finitude des prix, durées, spreads et coûts, puis refuser toute décision sur une valeur invalide. Valider aussi la configuration numérique ; une commission absente ne doit pas devenir silencieusement zéro via get(sym, 0.0).

## 4. Méthode et robustesse à clarifier

### C06 — P2 — Le seuil compare une médiane de moyennes horaires

Références : **collecte_couts.py:157–160** ; **analyse_couts.py:74–88**, **100–108** ; README:7–9.

Le collecteur calcule correctement une moyenne pondérée par le temps sous les réserves précédentes. Ensuite, le coût dit « médian » est la **médiane des moyennes horaires** augmentée de la commission. Ce n'est ni la médiane des spreads pondérés par le temps, ni une médiane de coûts aller-retour observés sur des exécutions. Le champ spread_median du collecteur est, lui, pondéré par le nombre de ticks et n'est pas utilisé pour ce verdict.

Ces mesures peuvent se trouver de part et d'autre de 1,75 pip : dans une heure avec un spread de 1 pip pendant 90 % du temps et 5 pips pendant 10 %, la moyenne temporelle est 1,4 pip et la médiane temporelle 1 pip. En ajoutant 0,5 pip de commission, on compare respectivement **1,9** ou **1,5** pip au seuil.

Il ne s'agit pas d'une erreur dans l'opérateur >, mais d'une définition de l'estimateur à faire valider explicitement avant d'interpréter les données. Si la médiane des moyennes horaires est bien la cible voulue, la nommer et documenter le poids accordé aux heures partiellement couvertes. Si la cible est la médiane temporelle, la calculer à partir des valeurs et durées adaptées ; une médiane de résumés horaires ne la reconstitue pas en général.

L'égalité exacte à 1,75 ne provoque pas d'abandon, conformément à « dépasse ». Le comparateur utilise le coût avant son arrondi d'affichage, mais les moyennes horaires ont déjà été arrondies à quatre décimales dans le collecteur. Garder la précision jusqu'à la décision ou fixer explicitement une politique de précision à la frontière.

### C07 — P2 — Des ticks de même milliseconde sont réordonnés par les prix

Références : **collecte_couts.py:142–150**.

valides.sort() trie les tuples par timestamp, puis bid, puis ask. En cas de timestamps identiques, le dernier prix conservé pour porter le poids jusqu'au timestamp suivant peut donc être le plus grand bid, et non la dernière cotation fournie par la source.

Exemple logique : deux cotations successives A puis B portent la même milliseconde, mais B a un bid plus faible. Le tri place B avant A et attribue à A le poids jusqu'au prochain timestamp. Le spread intégré peut changer.

Correction attendue : conserver l'ordre de source pour les ex aequo, tracer un indice d'ordre si nécessaire et définir la règle d'intégration des mises à jour simultanées. Conserver les données nécessaires pour auditer cette règle.

### N01 — Plafond d'appels : protection locale, pas preuve de quota serveur

Références : collecte_couts.py:48–76, 233–257, 321–334 ; README:14.

Le compteur plafonne les appels Python autorisés dans un processus, se remet à zéro au redémarrage et suit le jour UTC. Il ne mesure pas les requêtes réseau réellement produites par le terminal, les autres programmes ou les appels de synchronisation internes. Il ne suffit donc pas à prouver un respect du quota FTMO.

Quand le décalage reste inconnu, les deux lectures account_info et symbol_info_tick sont répétées chaque minute ; environ 200 passages peuvent consommer le budget de 400 en un peu plus de trois heures. Le programme s'arrête au plafond. shutdown passe par le même compteur et peut alors lever une seconde BudgetDepasse sans appeler la fonction réelle. Prévoir attente adaptée, reprise documentée et nettoyage indépendant du budget. Ne pas présenter le plafond comme persistant ou comme un compteur serveur.

### N02 — Provenance du compte et spécification incomplètes

Références : collecte_couts.py:212–221, 236–266, 314–320 ; README:45.

Seul le nom du serveur est conservé et comparé. Deux comptes différents sur le même serveur peuvent être mélangés dans le même dossier ; la devise n'est qu'affichée dans la console au démarrage. Le lot ne vérifie pas qu'il s'agit bien du compte FTMO et du type de compte prévus. Conserver une identité de collecte stable, sans mot de passe, ainsi que devise/type/serveur et empreintes du code et de la configuration ; refuser un mélange non déclaré.

La spécification promet une taille de tick mais n'enregistre pas trade_tick_size. Le champ point n'est pas une preuve générale de la taille minimale négociable. Ajouter le champ exact nécessaire au profil ; ne pas déclarer cet INCONNU résolu par déduction seule.

### N03 — Annonces et fuseaux

Références : analyse_couts.py:28–33, 48–53, 119–124 ; config_couts.json:15–20.

Une annonce ISO sans fuseau est convertie depuis le fuseau local du PC par astimezone, malgré la colonne nommée utc. Exiger un fuseau explicite ou une règle UTC documentée et validée. La colonne heure_prague_ce_jour utilise délibérément le fuseau de la date de génération, pas celui des observations : elle ne doit pas servir à reconstituer les heures historiques. Les fenêtres UTC fixes d'hiver sont signalées comme provisoires ; leur utilisation après un changement d'heure devra rester explicitement contrôlée.

## 5. Éléments corrects ou limites déjà déclarées

- Tous les appels MT5 visibles dans le collecteur passent par LectureSeule ; le module MetaTrader5 n'est importé que dans main. Aucune fonction d'ordre n'est appelée par les deux scripts relus. L'analyse ne dépend pas de MT5.
- Le découpage des ticks retient un début d'heure inclus et une fin exclue. Un tick de la borne de fin n'est pas attribué à deux heures.
- La formule somme(spread × durée) / somme(durée) et le quantile pondéré sont cohérents pour les données valides, complètes et ordonnées considérées.
- Un retour copy_ticks_range égal à None ne valide pas l'heure ; le collecteur essaie à nouveau au passage suivant, dans les limites de rattrapage et de budget.
- Le remplacement temporaire de etat.json protège ce fichier contre une écriture partielle ; il ne rend pas atomiques les autres sorties.
- Sous l'hypothèse d'un lot EURUSD de 100 000 unités avec résultat en USD, 5 USD aller-retour représentent bien 0,5 pip. **La commission reste configurée, non mesurée par ce lot.** Sa valeur contractuelle n'est pas certifiée par cet audit.
- Le glissement n'est pas mesuré et cette limite est annoncée. Les coûts produits sont des estimations fondées sur les cotations et une commission supposée ; ils ne prouvent pas les coûts d'exécution du futur bot.

## 6. Cas de validation à prévoir après correction — non exécutés ici

- Tick frais puis figé pendant 30 et 60 minutes ; timestamps API déjà UTC ; reprise traversant un changement d'heure.
- Interruption après chaque étape CSV/gzip/état, puis reprise ; lancement de deux instances ; détection des lignes horaires dupliquées.
- Réponse historique partielle, heure ouvrée vide puis disponible, fermeture attendue, intervalle sans changement de cotation et données invalides.
- 20 jours présents globalement mais fenêtre manquante ; fenêtre présente un seul jour ; annonce située dans une partie de l'heure non attestée.
- Prix, couverture, spread ou commission NaN/inf ; commission absente ; aucune décision chiffrée autorisée dans ces cas.
- Cotations distinctes avec time_msc identique et prix dans un ordre non lexicographique.
- Spreads variables à l'intérieur d'une heure pour distinguer moyenne et médiane ; coûts exactement à 1,75, juste au-dessous et juste au-dessus, avec politique de précision explicite.

## 7. Livraison de cette revue

Fichiers préparés dans le dossier local **POUR CLAUDE** :

- RETOUR_COUTS_L1_V01_2026-11-07.md : le présent rapport.
- COUTS_L1_V01_INTEGRITE.json : résultats exhaustifs des contrôles d'empreintes.

Ce dossier est local à l'environnement cloud. **Aucun dépôt dans Google Drive n'a pu être effectué : aucun accès Drive n'est configuré dans cette session.** Ces deux fichiers sont à transmettre dans le dossier POUR CLAUDE du Drive. Aucun fichier source du lot n'a été corrigé, aucun dépôt Git n'a été modifié et aucune publication n'a été effectuée.
