# Déposer le rapport dans Google Drive

Ce dossier contient le rapport, ses contrôles SHA256, un texte à copier dans ChatGPT et un script de transfert. Aucun script du lot de trading n'est inclus ni exécuté.

## Depuis ChatGPT

Joindre le rapport RETOUR_COUTS_L1_V01_2026-11-07.md et COUTS_L1_V01_INTEGRITE.json, puis copier le contenu de PROMPT_CHATGPT.txt. Fournir aussi le lien du dossier POUR CLAUDE.

Une connexion Google Drive ne garantit pas que ChatGPT dispose d'un outil d'écriture. Le texte fourni demande une confirmation fondée sur les fichiers réellement déposés. Le script ne peut pas ajouter un droit d'écriture absent de l'application.

## Transfert avec le script

Cette méthode nécessite Python 3, rclone et une autorisation Google Drive configurée dans l'environnement où le script est exécuté. Une connexion Google Drive dans ChatGPT ne configure pas automatiquement rclone, ni dans Codex ni sur le PC.

1. Installer rclone depuis https://rclone.org/downloads/ et Python 3 si nécessaire.
2. Ouvrir un terminal puis lancer `rclone config`.
3. Créer un remote nommé `gdrive`, de type Google Drive, puis suivre l'autorisation OAuth dans le navigateur pour le compte qui possède le dossier. Choisir un accès permettant l'écriture dans le dossier existant. Consulter https://rclone.org/drive/ pour la configuration. Ne jamais copier de mot de passe ou de jeton dans un chat.
4. Dans Drive, ouvrir exactement le dossier POUR CLAUDE concerné, sous CLAUDE_CORRECTION_EMA12_2026-10-30. Copier son ID : dans une URL de forme https://drive.google.com/drive/folders/IDENTIFIANT, il s'agit de IDENTIFIANT, sans les paramètres éventuels après le point d'interrogation.
5. Extraire complètement cette archive et ouvrir un terminal dans le dossier extrait.
6. Lancer la commande suivante en remplaçant IDENTIFIANT :

   `python envoyer_drive.py --remote gdrive --folder-id IDENTIFIANT`

   Sur Mac, utiliser `python3` si la commande `python` n'existe pas.

Le script envoie uniquement le rapport Markdown et le JSON d'intégrité. Il n'effectue aucune synchronisation destructive, aucun effacement et aucun changement des permissions de partage. Un fichier distant différent portant le même nom provoque un échec plutôt qu'un écrasement. Après chaque envoi, le fichier distant est relu et son SHA256 comparé au document local. Le message de fin ne s'affiche que si les deux contrôles réussissent.

Si le transfert échoue après le premier fichier, celui-ci peut déjà être présent. Relancer la même commande permet de terminer le dépôt si les fichiers présents sont identiques. Si les noms existent avec un contenu différent, examiner ce conflit avant toute modification manuelle.

## État de livraison

Le script de transfert n'a pas été exécuté lors de sa préparation. Aucun dépôt Drive n'est confirmé à ce stade. Le rapport porte sur la revue statique de COUTS_L1_V01 ; les scripts de collecte, d'analyse et de tests de ce lot n'ont pas été lancés.
